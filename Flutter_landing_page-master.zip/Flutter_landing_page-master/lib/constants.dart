import 'package:flutter/material.dart';

const kPrimaryColor = Color(0XFFFF4522);
const kSecondaryColor = Color(0XFF2B224B);
const kTextColor = Color(0XFF282828);
